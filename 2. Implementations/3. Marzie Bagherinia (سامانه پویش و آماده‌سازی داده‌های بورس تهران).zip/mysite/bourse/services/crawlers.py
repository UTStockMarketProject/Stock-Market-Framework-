import time
import requests
import datetime
import jdatetime
from bs4 import BeautifulSoup
from django.db.models import Sum, F
from persiantools.jdatetime import JalaliDate

from .constants import *
from .functions import *
from bourse.models import Indexes, Instrument, ChangeCapital, \
                          DayTradeSummary, ClientTradeInfo, DailyData

def get_instruments():
    print("Get Instruments Data!")
    
    cnt = 0
    for iid in get_instrument_ids():
        response = add_new_ins(iid[0])
        if response is True:
            add_new_codal(iid[0])
            complete_ins_fields(iid)

        print("Instrument number {num} was created successfully.".format(num = cnt))
        cnt += 1

def get_indexes():
    print("Get Indexes Data!")

    base_url = 'http://cdn.tsetmc.com/api/Index/GetIndexB2History/{id}'

    for iid in get_index_ids():
        response = requests.get(base_url.format(id = iid), headers = web_headers)

        if not response.ok:
            continue
        
        res = response.json()['indexB2']
        for record in res:
            i = record.get('dEven')
            if i >= str_default_start_date:
                date_ = convertStrToDate(str(i))
                Indexes.objects.update_or_create(
                    {
                        'date': date_,
                        indexDictEN[int(iid)]: record.get('xNivInuClMresIbs')
                    },
                    date=date_
                )

        print("{Index} Index was created successfully.".format(Index = indexDictEN[int(iid)]))

    # with open('log.txt', 'w') as f:
    #     for i in Indexes.objects.all():
    #         print(i.date, i.total, i.equalWeight, i.agriculture, i.coal, file=f)

def get_day_trade_summaries(date, ins):
    base_url = 'http://cdn.tsetmc.com/api/ClosingPrice/GetClosingPriceDaily/{instrument_id}/{date_str}'
    
    for i in Instrument.objects.filter(id__lte= ins, id__gte= ins):
        res = requests.get(base_url.format(instrument_id=i.instrumentId, date_str=date.strftime('%Y%m%d')), headers = web_headers)

        if not res.ok:
            print(f'get_day_trade_summaries for {i.id} (real id ={i.instrumentId}) response: {res.status_code}')
            return 500
            
        data = res.json()['closingPriceDaily']

        FinP = data['pClosing']

        DayTradeSummary.objects.update_or_create(
            {
                'instrumentId': i,
                'date': date,
                'lastPrice': data['pDrCotVal'],
                'finalPrice': FinP,
                'firstPrice': data['priceFirst'],
                'yesterdayPrice': data['priceYesterday'],
                'highestPrice': data['priceMax'],
                'lowestPrice': data['priceMin'],
                'tradeNum': data['zTotTran'],
                'tradeVol': data['qTotTran5J'],
                'tradeValue': data['qTotCap'],
            },
            date = date, instrumentId = i
        )
        if date >= i.updated_at:
            i.PdrCotVal = data['pDrCotVal']
            i.PClosing = data['pClosing']
            i.updated_at = date
            i.save()

def get_client_trade_infos(date, ins):
    base_url = 'http://cdn.tsetmc.com/api/ClientType/GetClientTypeHistory/{instrument_id}/{date_str}'

    for i in Instrument.objects.filter(id__lte= ins, id__gte= ins):
        res = requests.get(base_url.format(instrument_id=i.instrumentId, date_str=date.strftime('%Y%m%d')), headers = web_headers)
        if not res.ok:
            print(f'get_client_trade_infos for {i.id} (real id= {i.instrumentId}) response: {res.status_code}')
            return 500

        data = res.json()['clientType']
        bi_count = data['buy_I_Count']
        bi_value = data['buy_I_Value']
        bi_volume = data['buy_I_Volume']
        bn_count = data['buy_N_Count']
        bn_value = data['buy_N_Value']
        bn_volume = data['buy_N_Volume']
        si_count = data['sell_I_Count']
        si_value = data['sell_I_Value']
        si_volume = data['sell_I_Volume']
        sn_count = data['sell_N_Count']
        sn_value = data['sell_N_Value']
        sn_volume = data['sell_N_Volume']
        ClientTradeInfo.objects.update_or_create(
            {
                'date': date,
                'instrumentId': i,
                'numOfPersonBuyer': bi_count,
                'numOfCompanyBuyer': bn_count,
                'numOfPersonSeller': si_count,
                'numOfCompanySeller': sn_count,
                'volOfPersonBuyer': bi_volume,
                'volOfCompanyBuyer': bn_volume,
                'volOfPersonSeller': si_volume,
                'volOfCompanySeller': sn_volume,
                'volPercentageOfPersonBuyer': bi_volume / (bi_volume + bn_volume) if (bi_volume + bn_volume) > 0 else 0,
                'volPercentageOfCompanyBuyer': bn_volume / (bi_volume + bn_volume) if (bi_volume + bn_volume) > 0 else 0,
                'volPercentageOfPersonSeller': si_volume / (si_volume + sn_volume) if (si_volume + sn_volume) > 0 else 0,
                'volPercentageOfCompanySeller': sn_volume / (si_volume + sn_volume) if (si_volume + sn_volume) > 0 else 0,
                'valueOfPersonBuyer': bi_value,
                'valueOfCompanyBuyer': bn_value,
                'valueOfPersonSeller': si_value,
                'valueOfCompanySeller': sn_value,
                'avgPriceOfPersonBuyer': bi_value / bi_count if bi_count > 0 else 0,
                'avgPriceOfCompanyBuyer': bn_value / bn_count if bn_count > 0 else 0,
                'avgPriceOfPersonSeller': si_value / si_count if si_count > 0 else 0,
                'avgPriceOfCompanySeller': sn_value / sn_count if sn_count > 0 else 0,
                'changeFromPersonToCompany': bi_volume - bn_volume,
            },
            date=date, instrumentId=i
        )
    
def get_change_capitals():
    print("Get Change Capitals Data!")

    base_url = 'http://tsetmc.com/Loader.aspx?Partree=151310&Flow={flow}'

    for i in range(2):
        count = -1
        res = send_request(base_url.format(flow = i + 1))
        parsed_html = BeautifulSoup(res.content, features="html.parser")
        for row in parsed_html.findAll('tr'):
            count += 1
            if count == 0:
                continue
            try:
                iid = row.findAll('td')[1].find('a').get('href')[29:]
                date = jdatetime.datetime.strptime(row.findAll('td')[2].get_text(), '%Y/%m/%d').togregorian().date()
                new = get_num_from_str(row.findAll('td')[3].find('div').get('title'))
                old = get_num_from_str(row.findAll('td')[4].find('div').get('title'))
            except Exception as e:
                continue
            instrument = Instrument.objects.filter(instrumentId=iid)
            if not instrument.exists():
                print(f'instrument id: {iid} does not exist')
                continue
            ChangeCapital.objects.update_or_create(
                {
                    'date': date,
                    'instrumentId': instrument.last(),
                    'new_capital': new,
                    'old_capital': old,
                    'flow': i + 1,
                },
                date=date, instrumentId=instrument.last()
            )
            if count % 20 == 0:
                print(count)

def calculate_balanced_price(instrument_id):
    instrument = Instrument.objects.filter(instrumentId=instrument_id).last()
    change_capitals = ChangeCapital.objects.filter(instrumentId=instrument).order_by('-date')
    end_date = datetime.now().date()
    coefficient = 1.0
    for cc in change_capitals.all():
        start_date = cc.date
        DayTradeSummary.objects.filter(instrumentId=instrument, date__lte=end_date, date__gt=start_date).update(
            balancedPrice=F('finalPrice') * coefficient,
            balancedfirst=F('firstPrice') * coefficient,
            balancedlow=F('lowestPrice') * coefficient,
            balancedhigh=F('highestPrice') * coefficient
        )
        end_date = start_date
        coefficient = coefficient * (cc.old_capital / cc.new_capital)
    DayTradeSummary.objects.filter(instrumentId=instrument, date__lte=end_date, date__gt=date(1990, 1, 1)).update(
        balancedPrice=F('finalPrice') * coefficient,
        balancedfirst=F('firstPrice') * coefficient,
        balancedlow=F('lowestPrice') * coefficient,
        balancedhigh=F('highestPrice') * coefficient
    )

def create_daily_data():
    DailyData.objects.all().delete()

    cnt = 0
    for t in DayTradeSummary.objects.all().order_by('date'):
        print(cnt)
        cnt += 1

        try:
            a = ClientTradeInfo.objects.get(instrumentId = t.instrumentId, date = t.date)
        except ClientTradeInfo.DoesNotExist:
            continue

        try:
            b = Indexes.objects.get(date = t.date)
        except Indexes.DoesNotExist:
            b = Indexes.objects.update_or_create({'date': t.date}, date = t.date)

        if t.instrumentId.enGroupName is None or t.instrumentId.enGroupName == '':
            industryIndex = "agriculture"
        else:
            industryIndex = t.instrumentId.enGroupName

        DailyData.objects.create(
                    instrumentId = t.instrumentId,
                    date = t.date,
                    lastPrice = t.lastPrice,
                    finalPrice = t.finalPrice,
                    firstPrice = t.firstPrice,
                    yesterdayPrice = t.yesterdayPrice,
                    highestPrice = t.highestPrice,
                    lowestPrice = t.lowestPrice,
                    tradeNum = t.tradeNum,
                    tradeVol = t.tradeVol,
                    tradeValue = t.tradeValue,
                    balancedPrice = t.balancedPrice,
                    balancedhigh = t.balancedhigh,
                    balancedfirst = t.balancedfirst,
                    balancedlow = t.balancedlow,
                    numOfPersonBuyer = a.numOfPersonBuyer,
                    numOfCompanyBuyer = a.numOfCompanyBuyer,
                    numOfPersonSeller = a.numOfPersonSeller,
                    numOfCompanySeller = a.numOfCompanySeller,
                    volOfPersonBuyer = a.volOfPersonBuyer,
                    volOfCompanyBuyer = a.volOfCompanyBuyer,
                    volOfPersonSeller = a.volOfPersonSeller,
                    volOfCompanySeller = a.volOfCompanySeller,
                    valueOfPersonBuyer = a.valueOfPersonBuyer,
                    valueOfCompanyBuyer = a.valueOfCompanyBuyer,
                    valueOfPersonSeller = a.valueOfPersonSeller,
                    valueOfCompanySeller = a.valueOfCompanySeller,
                    changeFromPersonToCompany = a.changeFromPersonToCompany,
                    totalIndex = b.total,
                    equalWeightIndex = b.equalWeight,
                    industryIndex = getattr(b, industryIndex),
                    jalaliDate = str(JalaliDate(t.date)),
                    dayOfWeek = day_of_week[t.date.weekday()],
                    Lval18AFC = t.instrumentId.Lval18AFC,
                    enName = t.instrumentId.enName,
                    groupName = t.instrumentId.groupName,
                    enGroupName = t.instrumentId.enGroupName)

def unique_crawl(instrument, start_date, end_date = None):
    if end_date is not None and instrument.publishedDate is not None and instrument.publishedDate > end_date:
        return

    if instrument.publishedDate is not None and instrument.publishedDate > start_date:
        start_date = instrument.publishedDate

    for date in period_generator(start_date, end_date):
        if day_of_week[date.weekday()] == 'Thursday' or day_of_week[date.weekday()] == 'Friday':
            continue

        print(instrument.instrumentId, date)
        print()

        result_get_client_trade_infos = get_client_trade_infos(date, instrument.id)
        if result_get_client_trade_infos == 500:
            continue

        result_get_day_trade_summaries = get_day_trade_summaries(date, instrument.id)
        if result_get_day_trade_summaries == 500:
            continue


def start_change_capitals():
    get_change_capitals()
    for ins in Instrument.objects.all():
        calculate_balanced_price(ins.instrumentId)

def setup():
    get_indexes()
    get_instruments()

def crawl(start_date, end_date = None):
    global default_start_date, str_default_start_date

    if start_date < default_start_date:
        default_start_date = start_date
        str_default_start_date = start_date.strftime("%y%m%d")

    for ins in Instrument.objects.all():
        print("Crawling data for: {instrumentId} \n".format(instrumentId = ins.instrumentId))
        unique_crawl(ins, start_date, end_date)
        calculate_balanced_price(ins.instrumentId)
    
    create_daily_data()

def add_new_instrument(instrument_id, english_name = default_name, pub_date = add_default_start_date, start_date = default_start_date):
    if start_date == default_start_date:
       add_new_ins(instrument_id)
       add_new_codal(instrument_id)

    complete_ins_fields([instrument_id, english_name, pub_date])
    instrument = Instrument.objects.get(instrumentId = instrument_id)
    unique_crawl(instrument, start_date)

    get_change_capitals()
    calculate_balanced_price(instrument_id)
    #create_daily_data()

def start_crawling():
    today= datetime.now().date()
    yesterday = today - timedelta(days=1)
    crawl(yesterday, today)

def job_crawl():
    scheduled_hour = 4
    one_hour_to_seconds = 3600
    while(1==1):
        now = datetime.now()
        print(now)
        if( now.hour== scheduled_hour ):
            start_crawling()
        time.sleep(one_hour_to_seconds)

def job_capitals():
    scheduled_weekday = 2 #Wednesday
    one_day_to_seconds = 86400

    while(1==1):
        now = datetime.now()
        print(now)
        if(now.weekday() == scheduled_weekday):
            start_change_capitals()
        time.sleep(one_day_to_seconds)

def clear_db():
    DailyData.objects.all().delete()
    DayTradeSummary.objects.all().delete()
    ClientTradeInfo.objects.all().delete()
    Indexes.objects.all().delete()
    Codal.objects.all().delete()
    ChangeCapital.objects.all().delete()
    Instrument.objects.all().delete()
import csv
import time
import requests
from bs4 import BeautifulSoup
from django.conf import settings
from datetime import date, datetime, timedelta

from .constants import *
from bourse.models import Codal, Instrument, DayTradeSummary, ClientTradeInfo

def get_index_ids():
    res = []
    with open('indexes.csv') as cf:
        reader = csv.reader(cf)
        for i in reader:
            res.append(i[0])
    return res

def get_instrument_ids():
    res = []
    with open('ins.csv') as cf:
        reader = csv.reader(cf)
        for line in reader:
            temp = []
            for i in line:
                temp.append(i)
            res.append(temp)
    return res

def period_generator(start_date, end_date = None):
    end_date = end_date if end_date else datetime.now().date()
    while start_date <= end_date:
        yield start_date
        start_date += timedelta(days = 1)

def convertStrToDate(inputStr):
    year = int(inputStr[0:4])
    month = int(inputStr[4:6])
    day = int(inputStr[6:8])

    return date(year = year, month = month, day = day)

def get_script_var(scripts):
    if scripts is None or len(scripts) == 0:
        return '', '', '0', '0', '0'

    lSecVal = scripts[3].replace("LSecVal='", '').replace("'", '')
    insCode = scripts[7].replace("InsCode='", '').replace("'", '')
    eps = scripts[9].replace("EstimatedEPS='", '').replace("'", '')
    sectorPE = scripts[25].replace("SectorPE='", '').replace("'", '')
    psr = scripts[29].replace("PriceYesterday=0;ThemeCount='5';ContractSize='0';NAV='0';PSR='", '').replace("';", '')

    if eps == "":
        eps = '0'
    if sectorPE == "":
        sectorPE = '0'
    if psr == "":
        psr = '0'

    return lSecVal, insCode, eps, sectorPE, psr

def get_num_from_str(str_num: str):
    ten_power = 0
    num = 0
    for char in reversed(str_num):
        if char == ',':
            continue
        num += int(char) * 10 ** ten_power
        ten_power += 1
    return num

def send_request(base_url, time_out = 5):
    cnt = 1
    while True:
        try: 
            res = requests.get(base_url, headers = web_headers,  timeout = time_out)
            break
        except requests.exceptions.Timeout: 
            print('Attempt: ', cnt)
            cnt += 1

        time.sleep(2)

    return res

def add_new_ins(instrument_id):
    base_url = 'http://cdn.tsetmc.com/api/Instrument/GetInstrumentHistory/{id}/{date_str}'
    response = requests.get(base_url.format(id = instrument_id, date_str = datetime.now().strftime('%Y%m%d')), headers = web_headers)

    if not response.ok:
        return False
    
    res = response.json()['instrumentHistory']

    Instrument.objects.update_or_create(
        {
            'instrumentId': instrument_id,
            'Lval30': res.get('lVal30'),
            'Lval18AFC': res.get('lVal18AFC'),
            'FlowName': res.get('flowTitle'),
            'Flow': res.get('flow'),
            'CgrValCot': res.get('cgrValCot'),
            'ZTitad': res.get('zTitad'),
            'BaseVol': res.get('baseVol'),
            'insCode': res.get('insCode'),
            'CIsin': res.get('cIsin'),
            'PdrCotVal': res.get('PdrCotVal'),
            'PClosing': res.get('PClosing')
        },
        instrumentId=instrument_id,
    )

    return True

def add_new_codal(instrument_id):
    base_url = 'http://www.tsetmc.com/loader.aspx?ParTree=151311&i={id}'    
    res = send_request(base_url.format(id = instrument_id), 10)

    soup = BeautifulSoup(res.content, 'lxml')
    scripts_tag = soup.find('div', {'class': 'MainContainer'}).find_all('script')
    scripts = scripts_tag[0].get_text().split(',')

    lSecVal, insCode, eps, sectorPE, psr = get_script_var(scripts)

    Codal.objects.update_or_create(
        {
            'instrumentId': insCode,
            'eps': float(eps),
            'sectorPE': float(sectorPE),
            'psr': float(psr),
            'lSecVal': lSecVal,
            'date': last_update
        },
        instrumentId=instrument_id,
    )

def complete_ins_fields(ins_data):
    if len(ins_data) == 3:
        english_name, pub_date = ins_data[1], datetime.strptime(ins_data[2], '%y/%m/%d')
    else:
        english_name, pub_date = default_name, default_start_date

    instrument = Instrument.objects.get(instrumentId = ins_data[0])

    instrument.enName = english_name
    instrument.publishedDate = pub_date

    try:
        instrument.groupName = Codal.objects.get(instrumentId = instrument.instrumentId).lSecVal
    except Codal.DoesNotExist:
        instrument.groupName = ''

    instrument.save()

    try:
        instrument.enGroupName = indexDictPer[instrument.groupName]
    except KeyError:
        instrument.enGroupName = ''
    instrument.save()

def test(instrument_id):
    b = Instrument.objects.get(instrumentId = instrument_id)

    a = list(indexDictPer.keys())[11]
    print(a, len(a), b.groupName, len(b.groupName))    
    for i in range(len(b.groupName)):
        if a[i] != b.groupName[i]:
            print(a[i] + ' \ ' + b.groupName[i])

def test_1():
    for ins in Instrument.objects.all():
        print(ins.Lval18AFC, ins.Lval30)

def delete_noTrade_day(instrument_id):
    b = Instrument.objects.get(instrumentId = instrument_id)
    a =  DayTradeSummary.objects.filter(instrumentId = b)

    cnt = 0
    for t in a:
        try:
            c = ClientTradeInfo.objects.get(instrumentId = t.instrumentId, date = t.date)
        except ClientTradeInfo.DoesNotExist:
            t.delete()
            cnt += 1
            print(cnt)

    return cnt

def delete_none_clientInfo(instrument_id):
    b = Instrument.objects.get(instrumentId = instrument_id)
    a = ClientTradeInfo.objects.filter(instrumentId = b)

    cnt = 0
    for t in a:
        if t.date == None:
            t.delete()
            cnt += 1
            print(cnt)

    return cnt

def clear_db(instrument_id):
    b = Instrument.objects.get(instrumentId = instrument_id)
    cnt1 = delete_noTrade_day(instrument_id)
    cnt2 = delete_none_clientInfo(instrument_id)

    print("Delete no trade day for " , b.enName, ": " , cnt1)
    print("Delete none clientInfo for " , b.enName, ": " , cnt2)

def get_num_of_dc(instrument_id):
    b = Instrument.objects.get(instrumentId = instrument_id)
    print(DayTradeSummary.objects.filter(instrumentId = b).count())
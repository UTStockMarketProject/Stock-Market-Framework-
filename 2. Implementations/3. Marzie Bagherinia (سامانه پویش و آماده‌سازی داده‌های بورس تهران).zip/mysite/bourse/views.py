import csv
import pandas as pd
from io import StringIO
from django.conf import settings
from django.template import loader
from django.shortcuts import render
from django.http import HttpResponse
from django.core.files.base import File

from jalali_date import datetime2jalali

from .forms import ExportForm
from .models import DailyData, Instrument
from .services.constants import headers
from .services.features_generation.generateFeatures import add_features

# Create your views here.
def my_view(request):
	jalali_join = datetime2jalali(request.user.date_joined).strftime('%y/%m/%d _ %H:%M:%S')

def index(request):
    if request.method == 'POST':        
        exportForm = ExportForm(request.POST)
        exportForm.save()
        _type = request.POST.get('Type', '')
        instrument = request.POST.get('Instrument', '')

        if exportForm.is_valid():
            source = exportForm.cleaned_data['Source']
            destination = exportForm.cleaned_data['Destination']            
            return prepare_output(source, destination, _type, instrument)
        else:
            return prepare_output(_type = _type, instrument = instrument)

    else:
        exportForm = ExportForm(initial={'Source': "", 'Destination': ""})

    context = {
        'form': exportForm,
        'instruments': Instrument.objects.all(),
    }

    return render(request, 'index.html', context)

def prepare_output(source = None, destination = None, _type = "without", instrument = "all"):
    response = HttpResponse(content_type='text/csv')
    response['Content-Disposition'] = 'attachment; filename="export.csv"'

    if source is None or destination is None and instrument != "all":
        records = DailyData.objects.filter(Lval18AFC = instrument).values(*headers)
    elif source is not None and destination is not None and instrument == "all":
        records = DailyData.objects.filter(date__lte = destination, date__gte = source).values(*headers)
    elif source is not None and destination is not None and instrument != "all":
        records = DailyData.objects.filter(date__lte = destination, date__gte = source, Lval18AFC = instrument).values(*headers)
    else:
        records = DailyData.objects.all().values(*headers)


    writer = csv.DictWriter(response, fieldnames=headers)
    writer.writeheader()
    for record in records:
        writer.writerow(record)

    if _type == 'with':
        data = StringIO(response.content.decode('UTF-8'))
        df = pd.read_csv(data, sep=',')
        df = add_features(df)
        response.content = None
        df.to_csv(response, sep=',', index=False)
    return response
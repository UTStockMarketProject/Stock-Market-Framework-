from django import forms
from jalali_date.fields import JalaliDateField
from jalali_date.widgets import AdminJalaliDateWidget

from bourse.models import Export

class ContactForm(forms.Form):
    source = forms.DateField()
    destination = forms.DateField()

class ExportForm(forms.ModelForm):
    class Meta:
        model=Export
        fields='__all__'

    def __init__(self, *args, **kwargs):
        super(ExportForm, self).__init__(*args, **kwargs)
        self.fields["Source"] = JalaliDateField(label=('Source'), widget=AdminJalaliDateWidget)
        self.fields["Destination"] = JalaliDateField(label=('Destination'), widget=AdminJalaliDateWidget)

        self.fields["Source"].required = False
        self.fields["Destination"].required = False
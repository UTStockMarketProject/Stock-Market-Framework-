from django.db import models
from django.conf import settings

class Export(models.Model):
    Source = models.DateTimeField(null=True, blank=True)
    Destination = models.DateTimeField(null=True, blank=True)

class Instrument(models.Model):
    instrumentId = models.CharField(max_length=50, null=True, blank=True)
    Lval30 = models.CharField(max_length=30, null=True, blank=True)
    Lval18AFC = models.CharField(max_length=18, null=True, blank=True)
    FlowName = models.CharField(max_length=50, null=True, blank=True)
    Flow = models.SmallIntegerField(null=True, blank=True)
    CgrValCot = models.CharField(max_length=50, blank=True, null=True)
    ZTitad = models.BigIntegerField(null=True, blank=True)
    BaseVol = models.BigIntegerField(null=True, blank=True)
    insCode = models.CharField(max_length=50, blank=True, null=True)
    CIsin = models.CharField(max_length=50, blank=True, null=True)
    PdrCotVal = models.CharField(max_length=50, blank=True, null=True)
    PClosing = models.CharField(max_length=50, blank=True, null=True)
    enName = models.CharField(max_length=30, null=True, blank=True)
    groupName = models.CharField(max_length=100, null=True, blank=True)
    enGroupName = models.CharField(max_length=50, null=True, blank=True)
    publishedDate = models.DateField(blank=True, null=True)
    updated_at = models.DateField(default='1900-01-01')

    class Meta:
        db_table = 'instrument'

class Indexes(models.Model):
    date = models.DateField(blank=True, null=True)
    total = models.IntegerField(null=True, blank=True)
    equalWeight = models.IntegerField(null=True, blank=True)
    agriculture = models.IntegerField(null=True, blank=True)
    coal = models.IntegerField(null=True, blank=True)
    metalOre = models.IntegerField(null=True, blank=True)
    otherMines = models.IntegerField(null=True, blank=True)
    leather = models.IntegerField(null=True, blank=True)
    wood = models.IntegerField(null=True, blank=True)
    paper = models.IntegerField(null=True, blank=True)
    printing = models.IntegerField(null=True, blank=True)
    petroleum = models.IntegerField(null=True, blank=True)
    rubber = models.IntegerField(null=True, blank=True)
    basicMetals = models.IntegerField(null=True, blank=True)
    metals = models.IntegerField(null=True, blank=True) 
    machinery = models.IntegerField(null=True, blank=True)
    electrical = models.IntegerField(null=True, blank=True)
    communication = models.IntegerField(null=True, blank=True)
    car = models.IntegerField(null=True, blank=True)
    transportation = models.IntegerField(null=True, blank=True)
    sugar = models.IntegerField(null=True, blank=True)
    multidisciplinaryIndustry = models.IntegerField(null=True, blank=True)
    supply = models.IntegerField(null=True, blank=True)
    foodExceptSugar = models.IntegerField(null=True, blank=True)
    drug = models.IntegerField(null=True, blank=True)
    chemical = models.IntegerField(null=True, blank=True)
    ceramicTile = models.IntegerField(null=True, blank=True)
    cement = models.IntegerField(null=True, blank=True)
    nonMetallicMineral = models.IntegerField(null=True, blank=True)
    investment = models.IntegerField(null=True, blank=True)
    bank = models.IntegerField(null=True, blank=True)
    otherFinancial = models.IntegerField(null=True, blank=True)
    radio = models.IntegerField(null=True, blank=True)
    financial = models.IntegerField(null=True, blank=True)
    managingFinancialMarkets = models.IntegerField(null=True, blank=True)
    bulkMaker = models.IntegerField(null=True, blank=True)
    computer = models.IntegerField(null=True, blank=True)
    it = models.IntegerField(null=True, blank=True)
    engineering = models.IntegerField(null=True, blank=True)
    insurance = models.IntegerField(null=True, blank=True)
    retail = models.IntegerField(null=True, blank=True)
    
    class Meta:
        db_table = 'indexes'

class Codal(models.Model):
    date = models.DateField(blank=True, null=True)
    instrumentId = models.CharField(max_length=50, null=True, blank=True)
    eps = models.FloatField(null=True, blank=True)
    sectorPE = models.FloatField(null=True, blank=True)
    psr = models.FloatField(null=True, blank=True)
    lSecVal = models.CharField(max_length=50, null=True, blank=True)

    class Meta:
        db_table = 'codal'

class ClientTradeInfo(models.Model):
    date = models.DateField(blank=True, null=True)
    instrumentId = models.ForeignKey(Instrument, on_delete=models.CASCADE)
    numOfPersonBuyer = models.IntegerField(null=True, blank=True)
    numOfCompanyBuyer = models.IntegerField(null=True, blank=True)
    numOfPersonSeller = models.IntegerField(null=True, blank=True)
    numOfCompanySeller = models.IntegerField(null=True, blank=True)
    volOfPersonBuyer = models.BigIntegerField(null=True, blank=True)
    volOfCompanyBuyer = models.BigIntegerField(null=True, blank=True)
    volOfPersonSeller = models.BigIntegerField(null=True, blank=True)
    volOfCompanySeller = models.BigIntegerField(null=True, blank=True)
    volPercentageOfPersonBuyer = models.FloatField(null=True, blank=True)
    volPercentageOfCompanyBuyer = models.FloatField(null=True, blank=True)
    volPercentageOfPersonSeller = models.FloatField(null=True, blank=True)
    volPercentageOfCompanySeller = models.FloatField(null=True, blank=True)
    valueOfPersonBuyer = models.BigIntegerField(null=True, blank=True)
    valueOfCompanyBuyer = models.BigIntegerField(null=True, blank=True)
    valueOfPersonSeller = models.BigIntegerField(null=True, blank=True)
    valueOfCompanySeller = models.BigIntegerField(null=True, blank=True)
    avgPriceOfPersonBuyer = models.FloatField(null=True, blank=True)
    avgPriceOfCompanyBuyer = models.FloatField(null=True, blank=True)
    avgPriceOfPersonSeller = models.FloatField(null=True, blank=True)
    avgPriceOfCompanySeller = models.FloatField(null=True, blank=True)
    changeFromPersonToCompany = models.BigIntegerField(null=True, blank=True)

    class Meta:
        db_table = 'clienttradeinfo'

class DayTradeSummary(models.Model):
    instrumentId = models.ForeignKey(Instrument, on_delete=models.CASCADE)
    date = models.DateField(blank=True, null=True)
    lastPrice = models.IntegerField(blank=True, null=True)
    finalPrice = models.IntegerField(blank=True, null=True)
    firstPrice = models.IntegerField(blank=True, null=True)
    yesterdayPrice = models.IntegerField(blank=True, null=True)
    highestPrice = models.IntegerField(blank=True, null=True)
    lowestPrice = models.IntegerField(blank=True, null=True)
    tradeNum = models.IntegerField(blank=True, null=True)
    tradeVol = models.BigIntegerField(blank=True, null=True)
    tradeValue = models.BigIntegerField(blank=True, null=True)
    balancedPrice = models.FloatField(blank=True, null=True)
    balancedhigh = models.FloatField(blank=True, null=True)
    balancedfirst = models.FloatField(blank=True, null=True)
    balancedlow = models.FloatField(blank=True, null=True)

    class Meta:
        db_table = 'daytradesummary'

class ChangeCapital(models.Model):
    instrumentId = models.ForeignKey(Instrument, on_delete=models.CASCADE)
    date = models.DateField(blank=True, null=True)
    new_capital = models.BigIntegerField()
    old_capital = models.BigIntegerField()
    flow = models.SmallIntegerField()

class DailyData(models.Model):
    instrumentId = models.ForeignKey(Instrument, on_delete=models.CASCADE)
    date = models.DateField(blank=True, null=True)
    lastPrice = models.IntegerField(blank=True, null=True)
    finalPrice = models.IntegerField(blank=True, null=True)
    firstPrice = models.IntegerField(blank=True, null=True)
    yesterdayPrice = models.IntegerField(blank=True, null=True)
    highestPrice = models.IntegerField(blank=True, null=True)
    lowestPrice = models.IntegerField(blank=True, null=True)
    tradeNum = models.IntegerField(blank=True, null=True)
    tradeVol = models.BigIntegerField(blank=True, null=True)
    tradeValue = models.BigIntegerField(blank=True, null=True)
    balancedPrice = models.FloatField(blank=True, null=True)
    balancedhigh = models.FloatField(blank=True, null=True)
    balancedfirst = models.FloatField(blank=True, null=True)
    balancedlow = models.FloatField(blank=True, null=True)
    numOfPersonBuyer = models.IntegerField(null=True, blank=True)
    numOfCompanyBuyer = models.IntegerField(null=True, blank=True)
    numOfPersonSeller = models.IntegerField(null=True, blank=True)
    numOfCompanySeller = models.IntegerField(null=True, blank=True)
    volOfPersonBuyer = models.BigIntegerField(null=True, blank=True)
    volOfCompanyBuyer = models.BigIntegerField(null=True, blank=True)
    volOfPersonSeller = models.BigIntegerField(null=True, blank=True)
    volOfCompanySeller = models.BigIntegerField(null=True, blank=True)
    valueOfPersonBuyer = models.BigIntegerField(null=True, blank=True)
    valueOfCompanyBuyer = models.BigIntegerField(null=True, blank=True)
    valueOfPersonSeller = models.BigIntegerField(null=True, blank=True)
    valueOfCompanySeller = models.BigIntegerField(null=True, blank=True)
    changeFromPersonToCompany = models.BigIntegerField(null=True, blank=True)
    totalIndex = models.IntegerField(null=True, blank=True)
    equalWeightIndex = models.IntegerField(null=True, blank=True)
    industryIndex = models.IntegerField(null=True, blank=True)
    jalaliDate = models.CharField(max_length=10, null=True, blank=True)
    dayOfWeek = models.CharField(max_length=10, null=True, blank=True)

    Lval18AFC = models.CharField(max_length=18, null=True, blank=True)
    enName = models.CharField(max_length=30, null=True, blank=True)
    groupName = models.CharField(max_length=100, null=True, blank=True)
    enGroupName = models.CharField(max_length=50, null=True, blank=True)
    
    class Meta:
        db_table = 'dailyData'
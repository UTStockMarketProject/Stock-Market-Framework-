
import pandas as pd


def create_dataframe(d):
    df = pd.DataFrame(data= d)

    return df